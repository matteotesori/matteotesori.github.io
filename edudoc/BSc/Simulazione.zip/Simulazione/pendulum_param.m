
%%
%---------------------------------------------------------------------------------
% 0 Parametri
%---------------------------------------------------------------------------------

% Processo
Mc =  2.3900;           % massa carrello        [kg]
mp =  0.9400;           % massa disco           [kg]
Jp =  0.0727;           % inerzia asta          [kg*m^2]
l  =  0.5358;           % lunghezza asta        [m]
g  =  9.8100;           % gravit�               [m*s^(-2)]
a  =  9.7220;           % guadagno motore       [V*N^(-1)]
b  = 13.6111;           % attrito carrello      [kg*s^(-1)]
c  =  0.0000;           % attrito pendolo       [kg*m*s^(-1)]
Fs =  5.0000;           % attrito Coulomb       [N]
R  =  0.75;             % semilunghezza rotaie  [m]

% Disturbi
alpha  = 0.075;         % inclinazione rotaie
intimp = 1;             % ampiezza impulso di coppia
timp   = 65;            % istante di applicazione impulso di coppia
dimp   = 0.5;           % durata impulso di coppia

% Campionamento
t = 0.005;              % tempo di campionamento

% Condizioni iniziali
theta0 = pi;            % angolazione iniziale pendolo
r0     = 0.00;          % posizione iniziale carrello

% Setpoint
rsp =0;                 % posizione finale carrello

%---------------------------------------------------------------------------------
% 1 Definizione dei processi
%---------------------------------------------------------------------------------

% Processo TC
J=Jp+mp*l^2;
Mtot=Mc+mp;
detMat=Mtot*J-(mp*l)^2;

A=(detMat)^(-1)*[zeros(2,2) detMat*eye(2);0 (mp*l)^2*g -J*b -mp*l*c;0 Mtot*mp*l*g -mp*l*b -Mtot*c];
Bu=(detMat)^(-1)*[zeros(2,1);J;mp*l]*a;
Balpha=-Mtot*g/(a)*Bu;
Btau=(detMat)^(-1)*[zeros(2,1);mp*l;Mtot];
BFs=-(a)^(-1)*Bu;
C=[eye(3) zeros(3,1)];
Dalpha=-[0 1 0]';
D=0;

sys=ss(A,Bu,C,D);
sysalpha=ss(A,Balpha,C,Dalpha);
systau=ss(A,Btau,C,D);
sysFs=ss(A,BFs,C,D);

% Processo TD
sysd=c2d(sys,t);
sysdalpha=c2d(sysalpha,t);
sysdtau=c2d(systau,t);
sysdFs=c2d(sysFs,t);

[~,Gamma_u,~,~]=ssdata(sysd);
[~,Gamma_alpha,~,~]=ssdata(sysdalpha);
[~,Gamma_tau,~,~]=ssdata(sysdtau);
[Phi,Gamma_Fs,C,D]=ssdata(sysdFs);

% Processo esteso TC
ain=259.4707;
aout=227.2727;

Ae=[-ain zeros(1,7);Bu A zeros(4,3);zeros(3,1) aout*eye(3)*C -aout*eye(3)];
Bue=[ain;zeros(7,1)];
Balphae=[0;Balpha;aout*Dalpha];
Btaue=[0;Btau;zeros(3,1)];
BFse=[0;BFs;zeros(3,1)];
Ce=[zeros(3,1) zeros(3,4) eye(3)];

Cx=[zeros(4,1) eye(4) zeros(4,3)];

sys_e=ss(Ae,Bue,Ce,zeros(3,1));
sysalpha_e=ss(Ae,Balphae,Ce,zeros(3,1));
systau_e=ss(Ae,Btaue,Ce,zeros(3,1));
sysFs_e=ss(Ae,BFse,Ce,zeros(3,1));

% Processo esteso TD
sysd_e=c2d(sys_e,t);
sysdalpha_e=c2d(sysalpha_e,t);
sysdtau_e=c2d(systau_e,t);
sysdFs_e=c2d(sysFs_e,t);

[~,Gamma_ue,~,~]=ssdata(sysd_e);
[~,Gamma_alphae,~,~]=ssdata(sysdalpha_e);
[~,Gamma_taue,~,~]=ssdata(sysdtau_e);
[Phie,Gamma_Fse,Ce,De]=ssdata(sysdFs_e);

%---------------------------------------------------------------------------------
% 2 Dimensionamento stabilizzatore, swing up, osservatore non lineare
%---------------------------------------------------------------------------------

% Processo aumentato
Phi_a=[Phi [0 0 0 0]';[1 0 0 0] 1];
Gamma_ua=[Gamma_u; 0];

% Regolatore LQ
Q=diag([10 2000 2 2.5 0.001]);
R=0.1;
[F,~,e]=dlqr(Phi_a,Gamma_ua,Q,R);
Fx=F(1:4);
Fw=F(5);

% Osservatore robusto
E=0.9;
H=0;
[T,M,L1,L2]=robs(Phi,Gamma_u,E,H);

% Compensatore non lineare
Psi=Fs/a;

% Osservatore non lineare
ktau=1000;

% Swingup
ksu=0.7;
beta=0.4;
klim=2;

%---------------------------------------------------------------------------------
% 3 Simulazione
%---------------------------------------------------------------------------------

tStart=0;           %istante iniziale simulazione
tFinal=180;          %istante finale simulazione
sim('animazione', [tStart tFinal]);

%%
